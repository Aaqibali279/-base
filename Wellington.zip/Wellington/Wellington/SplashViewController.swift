//
//  ViewController.swift
//  Wellington
//
//  Created by Aqib Ali on 12/09/20.
//  Copyright © 2020 Aqib Ali. All rights reserved.
//

import UIKit

class SplashViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        ProfileViewModel.shared.profile { result in
            switch result{
            case .success:
                if let vc = R.storyboard.dashboard.dashboardViewController(){
                    self.navigationController?.setViewControllers([vc], animated: true)
                }
            case .failure:
                if let vc = R.storyboard.main.loginViewController(){
                    self.navigationController?.setViewControllers([vc], animated: true)
                }
            }
        }
        
    }


}

