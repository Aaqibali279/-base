//
//  MyUserDefaults.swift
//  KeepSake
//
//  Created by Aqib Ali on 11/01/20.
//  Copyright © 2020 Aqib Ali. All rights reserved.
//

import Foundation
struct MyUserDefaults {
    private let defaults = UserDefaults.standard

    private init(){}
    static var instance = MyUserDefaults()

    enum Key:String {
        case token,passwordToken,email,timeStamp
    }

    func set<T>(value:T,key:Key){
        defaults.set(value, forKey: key.rawValue)
    }
    
    func get<T>(key:Key) -> T?{
        return defaults.value(forKey: key.rawValue) as? T
    }
    
}
