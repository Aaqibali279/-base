//
//  Constants.swift
//  Wellington
//
//  Created by Aqib Ali on 20/09/20.
//  Copyright © 2020 Aqib Ali. All rights reserved.
//

import Foundation

public let NOT_AVAILABLE = "N/A"
