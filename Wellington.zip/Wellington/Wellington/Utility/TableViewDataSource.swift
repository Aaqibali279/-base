//
//  TableViewDataSource.swift
//  Wellington
//
//  Created by Aqib Ali on 18/09/20.
//  Copyright © 2020 Aqib Ali. All rights reserved.
//

import UIKit


typealias CellForRowAt<T> = (T,IndexPath) -> UITableViewCell
typealias HeaderForSection = (Int) -> UIView
typealias LoadMoreData = (Int) -> ()


class TableViewDelegateDatasource<T>:NSObject,UITableViewDelegate,UITableViewDataSource {
    
    var items = Array<T>()
    private var cellForRowAt:CellForRowAt<T>
    private var headerForSection:HeaderForSection?
    private var heightForHeader:CGFloat
    private var loadMoreData:LoadMoreData?
    
    init(heightForHeader:CGFloat = 0,cellForRowAt:@escaping CellForRowAt<T>,headerForSection: HeaderForSection? = nil,loadMoreData:LoadMoreData? = nil) {
        self.cellForRowAt = cellForRowAt
        self.headerForSection = headerForSection
        self.heightForHeader = heightForHeader
        self.loadMoreData = loadMoreData
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        items.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        cellForRowAt(items[indexPath.row],indexPath)
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        headerForSection?(section)
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        heightForHeader
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        if scrollView.contentOffset.y > (scrollView.contentSize.height - 100 - scrollView.frame.height){
            loadMoreData?(items.count)
        }
        
    }
    
}
