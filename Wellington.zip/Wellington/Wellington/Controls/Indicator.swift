//
//  Indicator.swift
//  Story
//
//  Created by Aquib on 05/08/19.
//  Copyright © 2019 Aquib. All rights reserved.
//

import UIKit
import Foundation
import NVActivityIndicatorView
class Indicator: UIViewController , NVActivityIndicatorViewable {
    static let instance = Indicator()

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    
    func show(loadingText:String) {
        let size = CGSize(width: 30, height: 30)
        
        startAnimating(size, message: "\(loadingText)...",messageFont: .systemFont(ofSize: 18, weight: .light), type: .ballPulse, color: R.color.primaryColor(), backgroundColor: UIColor.white.withAlphaComponent(0.2), textColor: R.color.primaryColor())
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 1.5) {
            NVActivityIndicatorPresenter.sharedInstance.setMessage("please wait...")
        }
    }
    
    func hide() {
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now()) {
            self.stopAnimating(nil)
        }
    }
    
}
