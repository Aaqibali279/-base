//
//  SearchHeaderView.swift
//  Wellington
//
//  Created by Aqib Ali on 12/09/20.
//  Copyright © 2020 Aqib Ali. All rights reserved.
//

import UIKit

protocol SearchHeaderViewDelegate:class {
    func search(from text:String)
    func reloadAll()
    func add()
}


class SearchHeaderView: UIView,UITextFieldDelegate {
    
    private weak var delegate:SearchHeaderViewDelegate?
    
    private lazy var textField = { () -> UITextField in
        let field = UITextField()
        field.placeholder = "Search"
        field.tintColor = R.color.primaryColor()
        field.font = .systemFont(ofSize: 17)
        
        let rightView = UIView(frame: CGRect(x: 0, y: 0, width: 50, height: 40))
        let iv = UIImageView(frame: .init(x: 12, y: 8, width: 30, height: 24))
        iv.tintColor = .gray
        iv.contentMode = .scaleAspectFit
        iv.image = UIImage(systemName: "magnifyingglass",weight: .light)
        rightView.addSubview(iv)
        
        field.leftView = rightView
        field.leftViewMode = .always
        field.translatesAutoresizingMaskIntoConstraints = false
        field.heightAnchor.constraint(equalToConstant: 40).isActive = true
        field.backgroundColor = UIColor.lightGray.withAlphaComponent(0.2)
        field.layer.cornerRadius = 20
        field.clipsToBounds = true
        return field
    }()
    
    private let btnAdd = { () -> UIButton in
       let btn = UIButton()
        btn.setImage(UIImage(systemName: "plus", weight: .light), for: .normal)
        btn.backgroundColor = R.color.primaryColor()
        btn.tintColor = .white
        btn.translatesAutoresizingMaskIntoConstraints = false
        btn.widthAnchor.constraint(equalToConstant: 40).isActive = true
        btn.heightAnchor.constraint(equalToConstant: 40).isActive = true
        btn.layer.cornerRadius = 20
        btn.clipsToBounds = true
        btn.addTarget(self, action: #selector(add), for: .touchUpInside )
        return btn
    }()
    
    @objc func add(){
        delegate?.add()
    }
    
    init(delegate:SearchHeaderViewDelegate){
        super.init(frame: .zero)
        self.delegate = delegate
        textField.delegate = self
        
        backgroundColor = .white
        
        let stack = UIStackView(arrangedSubviews: [textField,btnAdd])
        stack.alignment = .fill
        stack.distribution = .fillProportionally
        stack.axis = .horizontal
        stack.spacing = 16
        stack.translatesAutoresizingMaskIntoConstraints = false
        
        addSubview(stack)
        
        stack.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 16).isActive = true
        stack.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -16).isActive = true
        stack.centerYAnchor.constraint(equalToSystemSpacingBelow: centerYAnchor, multiplier: 1).isActive = true
        
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let text = NSString(string: textField.text!).replacingCharacters(in: range, with: string).lowercased()
        if text.count == 0{
            delegate?.reloadAll()
        }else{
            delegate?.search(from: text)
        }
        return true
    }
    
}
