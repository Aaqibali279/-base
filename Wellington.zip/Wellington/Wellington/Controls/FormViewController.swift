//
//  FormViewController.swift
//  WalletX
//
//  Created by ElintMinds_11 on 05/03/20.
//  Copyright © 2020 ElintMinds_11. All rights reserved.
//

import UIKit

class FormViewController: UIViewController {
    
    var returnKeyType:UIReturnKeyType = .done
    
//    var emailField:FloatingTextField?
    var passwordFields = [FloatingTextField]()
    
    var fields:Array<UITextField> = []{
        didSet{
            for field in fields{
                field.returnKeyType = .next
                if field ==  fields.last{
                    field.returnKeyType = returnKeyType
                }
                field.delegate = self
            }
        }
    }
    
    
    func doneAction(){
        
    }
    
}

extension FormViewController:UITextFieldDelegate{
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        for (index,field) in fields.enumerated(){
            if field == textField && index != fields.count - 1{
                fields[index + 1].becomeFirstResponder()
                break
            }else{
                field.resignFirstResponder()
                if index == fields.count - 1{
                    doneAction()
                }
            }
        }
        
        return true
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let text = NSString(string:textField.text!).replacingCharacters(in: range, with: string)
        
        if let textField = textField as? FloatingTextField{
            if text.count > 0 {
                textField.errorMessage = nil
            }
        }
        
        return true
        
    }
    
    
}



extension UIViewController{
    
    func set(title:String?,titleColor:UIColor = UIColor.black,prefersLargeTitles:Bool = true,font: UIFont? = UIFont.systemFont(ofSize: 16)){
        
        navigationController?.view.backgroundColor = .white
        showNavBar()
        self.navigationItem.title = title
        self.navigationController?.navigationBar.isTranslucent = false
        self.navigationItem.setHidesBackButton(true, animated: false)
        self.navigationController?.navigationBar.barTintColor = .white
        self.navigationController?.navigationBar.prefersLargeTitles = prefersLargeTitles
        self.navigationController?.navigationBar.backgroundColor = .white
        
        let navBarAppearance = UINavigationBarAppearance()
        navBarAppearance.configureWithDefaultBackground()
        navBarAppearance.shadowImage = UIImage()
        navBarAppearance.shadowColor = .clear
        navBarAppearance.titleTextAttributes = [.foregroundColor: titleColor,
                                                .font:font!]
        navBarAppearance.backgroundColor = .white
        self.navigationController?.navigationBar.standardAppearance = navBarAppearance
        self.navigationController?.navigationBar.compactAppearance = navBarAppearance
        
        
    }
    
    
    @objc func back(){
        navigationController?.popViewController(animated: true)
    }
    
    
    func setBackButton(){
        setLeftBarButton(selector:#selector(back),image:UIImage(systemName: "chevron.left"))
    }
    
    func setLeftBarButton(selector:Selector,image:UIImage?){
        showNavBar()
        let backBtn = UIButton(frame: .init(origin: .zero, size: .init(width: 44, height: 44)))
        backBtn.tintColor = .black
        backBtn.setImage(image, for: .normal)
        backBtn.contentHorizontalAlignment = .leading
        backBtn.addTarget(self, action: selector, for: .touchUpInside)
        let leftBarButtonItem = UIBarButtonItem(customView: backBtn)
        navigationItem.leftBarButtonItem = leftBarButtonItem
    }
    
    func showNavBar(){
        navigationController?.isNavigationBarHidden = false
    }
    
    func hideNavBar(){
        navigationController?.isNavigationBarHidden = true
    }
    
    func setRightBarButton(with image:UIImage?,tintColor:UIColor? = .black,selector:Selector){
        setRightBarButton(tintColor: tintColor, selector: selector,image: image)
    }
    
    func setRightBarButton(with title:String?,tintColor:UIColor? = .black,selector:Selector){
        setRightBarButton(tintColor: tintColor, selector: selector, title: title)
    }
    
    private func setRightBarButton(tintColor:UIColor? = .black,selector:Selector,image:UIImage? = nil,title:String? = nil){
        showNavBar()
        let item:UIBarButtonItem
        if let image = image{
            item = UIBarButtonItem(image: image, style: .plain, target: self, action: selector)
        }else{
            item = UIBarButtonItem(title: title, style: .plain, target: self, action: selector)
        }
        
        item.tintColor = tintColor
        if var items = navigationItem.rightBarButtonItems{
            items.append(item)
            navigationItem.rightBarButtonItems = items
        }else{
            navigationItem.rightBarButtonItems = [item]
        }
    }
    
    func logout() {
        if let vc = R.storyboard.main.loginViewController(){
            vc.isLogout = true
            navigationController?.setViewControllers([vc], animated: false)
        }
    }
    
    
    
}
