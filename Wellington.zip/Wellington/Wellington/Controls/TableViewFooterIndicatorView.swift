//
//  TableViewFooterView.swift
//  Wellington
//
//  Created by Aqib Ali on 18/09/20.
//  Copyright © 2020 Aqib Ali. All rights reserved.
//

import UIKit
import EZSwiftExtensions

public let indicatorFooterView = TableViewFooterIndicatorView()

public class TableViewFooterIndicatorView: UIView {
    
    init(){
        super.init(frame: .init(origin: .zero, size: .init(width: ez.screenWidth, height: 80)))
        let indicator = UIActivityIndicatorView(style: .medium)
        indicator.color = R.color.primaryColor()
        indicator.center = center
        indicator.frame = frame
        indicator.startAnimating()
        addSubview(indicator)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
