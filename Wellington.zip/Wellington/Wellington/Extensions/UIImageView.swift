//
//  UIImageView.swift
//  Wellington
//
//  Created by Aqib Ali on 16/09/20.
//  Copyright © 2020 Aqib Ali. All rights reserved.
//

import Foundation
import Kingfisher

public let imagePlaceholder = UIImage(systemName: "photo",withConfiguration: UIImage.SymbolConfiguration(weight: .ultraLight))

extension UIImageView{
    
    func set(imageFrom urlString:String?,completion:((UIImage) -> Void)? = nil){
        
        guard let urlString = urlString else {
            image = imagePlaceholder
            return
        }
        let baseUrl = Api.imageBaseUrl.rawValue
        let imageUrlString = baseUrl + urlString
        guard let imageUrl = imageUrlString.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) else { return }
        let url = URL(string: imageUrl)
        kf.indicatorType = .activity
        kf.setImage(
            with: url,
            placeholder: imagePlaceholder,
            options: [
                .scaleFactor(UIScreen.main.scale),
                .transition(.fade(1)),
                .cacheOriginalImage
            ])
        {
            result in
            switch result {
            case .success(let value):
                completion?(value.image)
                print("Task done for: \(value.source.url?.absoluteString ?? "")")
            case .failure(let error):
                print("Job failed: \(error.localizedDescription)")
            }
        }
    }
    
}

