//
//  Apis.swift
//  ADChat
//
//  Created by Aquib on 06/08/19.
//  Copyright © 2019 Aquib. All rights reserved.
//

import Foundation
enum Api:String {
    case baseUrl = "http://wellington.leagueofclicks.com/api/auth/"
    case imageBaseUrl = "http://wellington.leagueofclicks.com/"
    
    case login = "login"
    case user = "user-details"
    
    case services = "admin/list-services-mobile"
    case managers = "admin/list-manager-mobile"
    case haulers = "admin/list-hauler-mobile"
    case drivers = "admin/list-drivers-mobile"
    case admins = "admin/list-admin-mobile"
    case customers = "admin/list-customer-mobile"
    case jobs = "admin/job-list-mobile"
    case vehicles = "admin/list-vehicle-mobile"
    case skidsteers = "admin/list-skidsteer"
    
    case addCart = "user/cart/add-item"
    case cartUpdate = "user/cart/update"
    case placeOrder = "user/order/create"
}
