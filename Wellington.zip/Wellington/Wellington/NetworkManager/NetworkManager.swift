//
//  Network.swift
//  ADChat
//
//  Created by Aquib on 06/08/19.
//  Copyright © 2019 Aquib. All rights reserved.
//

import Foundation
import Alamofire


struct Status<T:Decodable>:Decodable {
    let status:Bool
    let message:String?
    let data:T?
    
    enum CodingKeys: String, CodingKey {
      case status, message, data
    }
    
    init(from decoder: Decoder) throws{
        let container = try decoder.container(keyedBy: CodingKeys.self)
        status = try container.decode(Bool.self, forKey: .status)
        message = try container.decode(String.self, forKey: .message)
        do {
            data = try container.decode(T.self, forKey: .data)
        } catch {
            data = nil
        }
    }
}

struct Messages {
    static let error = "Something went wrong"
    static let network = "Network not available"
}

enum Result {
    case success,failure
}

enum NetworkResult<T:Decodable> {
    case success(T?)
    case failure(String?)
}

struct NetworkManager {
    
    static let instance = NetworkManager()
    private init(){}
    
    func request<T:Decodable>(endPoint: Api,
                                    method:HTTPMethod = .post,
                                    parameters: [String: Any]? = nil,
                                    showIndicator: Bool = true,
                                    loadingText:String = "loading",
                                    completion: ((NetworkResult<T>) -> Void)? = nil) {
        
        if !NetworkReachabilityManager()!.isReachable {
            completion?(.failure(Messages.network))
            showSnackBar(message: Messages.network)
            return
        }
        
        
        var header = [String: String]()
        
        if let token:String = MyUserDefaults.instance.get(key: .token),token.count > 0{
            header["Authorization"] = "Bearer \(token)"
            header["X-Requested-With"] = "XMLHttpRequest"
            header["Content-Type"] = "application/json"
        }
        
        
        let urlString = Api.baseUrl.rawValue + endPoint.rawValue
        debugPrint("********************************* API Request **************************************")
        debugPrint("Request URL: ",urlString)
        debugPrint("Request Parameters: ",parameters ?? "no parameters")
        debugPrint("Request Headers: ",header)
        debugPrint("************************************************************************************")
        
        guard let url = URL(string: urlString) else{
            completion?(.failure(Messages.error))
            showSnackBar(message: Messages.error)
            return
        }
        if showIndicator {
            DispatchQueue.main.async {
                Indicator.instance.show(loadingText: loadingText)
            }
        }
        Alamofire.request(url
            , method: method
            , parameters: parameters
            , encoding: URLEncoding.queryString
            , headers: header).responseData { (dataResponse) in
                
                if showIndicator {
                    DispatchQueue.main.async {
                        Indicator.instance.hide()
                    }
                }
                if let error = dataResponse.error{
                    completion?(.failure(error.localizedDescription))
                    showSnackBar(message:error.localizedDescription)
                    return
                }
                
                guard let data = dataResponse.data else{
                    completion?(.failure(Messages.error))
                    showSnackBar(message: Messages.error)
                    return
                }
                
                debugPrint("********************************* RESPONSE START **************************************")
                
                do{
                    let json = try JSONSerialization.jsonObject(with: data, options: .allowFragments)
                    debugPrint("JSON",json)
                }catch{
                    
                }
                
                do{
                    let response = try JSONDecoder().decode(Status<T>.self, from: data)
                    switch response.status{
                    case true:
                        completion?(.success(response.data))
                    default:
                        completion?(.failure(response.message))
                        showSnackBar(message: response.message)
                    }
                }catch{
                    completion?(.failure(Messages.error))
                    debugPrint("ERROR:",error)
                }
                debugPrint("********************************* RESPONSE END **************************************")
                
        }
    }

    
    
    
    
    
    
//    func multipart<Element:Decodable>(endpoint: Api, image: [String: Data],
//                parameters: [String: AnyObject]? = nil,
//                showIndicator: Bool = true, success: @escaping Success<Element>,
//                message:@escaping ErrorMessage) {
//        if !NetworkReachabilityManager()!.isReachable {
//            message(Messages.network)
//            return
//        }
//
//        if showIndicator {
//            Indicator.instance.show()
//        }
//
//        let apiString = Api.baseUrl.rawValue + endpoint.rawValue
//
//
//        var headers = [String: String]()
//        headers["Accept"] = " application/json"
//        headers["Device"] = "ios"
//        headers["Client-token"] = "DH#K@H8%IJ9&%*H"
//
//        if let token:String = MyUserDefaults.instance.get(key: .token),token.count > 0{
//            headers["Authorization"] = "Bearer \(token)"
//        }
//
//
//        print(apiString)
//        debugPrint("********************************* API Request **************************************")
//        debugPrint("Request URL:\(apiString)")
//        debugPrint("Request Parameters: \(parameters ?? [: ])")
//        debugPrint("Request Headers: \(headers )")
//        debugPrint("************************************************************************************")
//
//
//        Alamofire.upload(multipartFormData: { multipartFormData in
//            if let params = parameters {
//                for (key, value) in params {
//                    multipartFormData.append(value.data(using: String.Encoding.utf8.rawValue)!, withName: key)
//                }
//            }
//            for (key,value) in image {
//                let interval = NSDate().timeIntervalSince1970 * 1000
//                let imgMimeType : String = "image/jpg"
//                let imgFileName = "img\(interval).jpg"
//                multipartFormData.append(value, withName: key, fileName: imgFileName, mimeType: imgMimeType)
//            }
//        }, to: apiString,headers: headers,
//           encodingCompletion: { encodingResult in
//            switch encodingResult {
//            case .success(let upload, _, _):
//
//                upload.responseData(completionHandler: { (dataResponse) in
//                    if showIndicator {
//                        DispatchQueue.main.async {
//                            Indicator.instance.hide()
//                        }
//                    }
//
//                    if let error = dataResponse.error{
//                        message(error.localizedDescription)
//                        return
//                    }
//
//                    guard let data = dataResponse.data else{
//                        message(Messages.error)
//                        return
//                    }
//
//                    debugPrint("********************************* RESPONSE START **************************************")
//                    do{
//                        let json = try JSONSerialization.jsonObject(with: data, options:.allowFragments)
//                        debugPrint("JSON: ",json)
//                    }catch{
//                        debugPrint("ERROR:",error)
//                    }
//
//                    do{
//                        let status = try JSONDecoder().decode(Status<Element>.self, from: data)
//                        switch status.error{
//                        case false:
//                            success(status.data,status.message)
//                        default:
//                            message(status.message)
//                        }
//                    }catch{
//                        message(Messages.error)
//                        debugPrint("ERROR:",error)
//                    }
//                    debugPrint("********************************* RESPONSE END **************************************")
//                })
//            case .failure(let error):
//                message(error.localizedDescription)
//            }
//
//        })
//
//    }
    
}

struct Response:Decodable {
    
}
