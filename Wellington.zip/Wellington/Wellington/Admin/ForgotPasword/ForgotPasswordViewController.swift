//
//  ForgotPasswordViewController.swift
//  Wellington
//
//  Created by Aqib Ali on 12/09/20.
//  Copyright © 2020 Aqib Ali. All rights reserved.
//

import UIKit

class ForgotPasswordViewController: UIViewController {

    
    //MARK:- OUTLETS
    @IBOutlet weak var otpView: OTPTextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        set(title: nil)
        setBackButton()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        hideNavBar()
    }
    
    //MARK:- ACTIONS
    @IBAction func btnContinueAction(_ sender: Any) {
        
    }
    
}
