//
//  MenuItem.swift
//  Wellington
//
//  Created by Aqib Ali on 12/09/20.
//  Copyright © 2020 Aqib Ali. All rights reserved.
//

import UIKit

struct Menu {
    let image:UIImage?
    let title:String
}

class MenuItemView: UIView {
    
    private let imageView = { () -> UIImageView in
        let iv = UIImageView()
        iv.tintColor = R.color.primaryColor()
        iv.contentMode = .scaleAspectFit
        iv.translatesAutoresizingMaskIntoConstraints = false
        return iv
    }()
    
    private let label = { () -> UILabel in
        let lb = UILabel()
        lb.textColor = .label
        lb.font = .systemFont(ofSize: 14)
        lb.translatesAutoresizingMaskIntoConstraints = false
        return lb
    }()
    
    init(menu:Menu) {
        super.init(frame: .zero)
        addSubview(imageView)
        addSubview(label)
        imageView.image = menu.image
        label.text = menu.title
        
        imageView.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 16).isActive = true
        imageView.widthAnchor.constraint(equalToConstant: 24).isActive = true
        imageView.heightAnchor.constraint(equalToConstant: 24).isActive = true
        imageView.centerYAnchor.constraint(equalTo: centerYAnchor).isActive = true
        imageView.widthAnchor.constraint(equalTo: imageView.heightAnchor, multiplier: 1).isActive = true
        
        label.leadingAnchor.constraint(equalTo: imageView.trailingAnchor, constant: 8).isActive = true
        label.centerYAnchor.constraint(equalTo: centerYAnchor).isActive = true
        
        
        
        let arrowImageView = UIImageView(image: UIImage(systemName: "chevron.right",weight: .ultraLight))
        arrowImageView.tintColor = .black
        arrowImageView.contentMode = .scaleAspectFit
        arrowImageView.translatesAutoresizingMaskIntoConstraints = false
        
        addSubview(arrowImageView)
        
        arrowImageView.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -16).isActive = true
        arrowImageView.widthAnchor.constraint(equalToConstant: 16).isActive = true
        arrowImageView.heightAnchor.constraint(equalToConstant: 16).isActive = true
        arrowImageView.centerYAnchor.constraint(equalTo: centerYAnchor).isActive = true
        
        layoutIfNeeded()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}

class MenuHeader:UIView {
    
    let imageView = { () -> UIImageView in
        let iv = UIImageView()
        iv.contentMode = .scaleAspectFill
        iv.clipsToBounds = true
        iv.layer.cornerRadius = 6
        iv.translatesAutoresizingMaskIntoConstraints = false
        return iv
    }()
    
    private let namelabel = { () -> UILabel in
        let lb = UILabel()
        lb.textColor = .black
        lb.font = .boldSystemFont(ofSize: 20)
        lb.translatesAutoresizingMaskIntoConstraints = false
        return lb
    }()
    
    private let emailabel = { () -> UILabel in
        let lb = UILabel()
        lb.textColor = .black
        lb.font = .systemFont(ofSize: 12)
        lb.translatesAutoresizingMaskIntoConstraints = false
        return lb
    }()
    
    
    init() {
        super.init(frame: .zero)
        addSubview(imageView)
        
        var topInset:CGFloat = 20
        let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene
        if let sceneDelegate = windowScene?.delegate as? SceneDelegate{
            topInset = (sceneDelegate.window?.safeAreaInsets.top ?? 0)
        }
        
        backgroundColor = .white
        
        imageView.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 16).isActive = true
        imageView.topAnchor.constraint(equalTo: topAnchor, constant: topInset).isActive = true
        imageView.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -4).isActive = true
        imageView.widthAnchor.constraint(equalTo: imageView.heightAnchor,multiplier: 1.2).isActive = true
        imageView.tintColor = R.color.primaryColor()
        
        let stackView = UIStackView(arrangedSubviews: [namelabel,emailabel])
        stackView.distribution = .fill
        stackView.axis = .vertical
        stackView.alignment = .fill
        stackView.translatesAutoresizingMaskIntoConstraints = false
        addSubview(stackView)
        
        stackView.topAnchor.constraint(equalTo: imageView.topAnchor).isActive = true
        stackView.leadingAnchor.constraint(equalTo: imageView.trailingAnchor, constant: 8).isActive = true
        stackView.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -16).isActive = true
        
        layoutIfNeeded()
    }
    
    
    var userViewModel:UserViewModel?{
        didSet{
            namelabel.text = userViewModel?.name
            emailabel.text = userViewModel?.email
        }
    }
    
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}

extension UIImage{
    convenience init?(systemName:String,weight:SymbolWeight) {
        self.init(systemName:systemName,withConfiguration:UIImage.SymbolConfiguration(weight: weight))
    }
}
