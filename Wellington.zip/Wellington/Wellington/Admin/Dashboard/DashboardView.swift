//
//  DashboardView.swift
//  Wellington
//
//  Created by Aqib Ali on 13/09/20.
//  Copyright © 2020 Aqib Ali. All rights reserved.
//

import UIKit
import EZSwiftExtensions

class DashboardView: UIView {

    //MARK:- OUTLETS
    
    @IBOutlet weak var collectionView: UICollectionView!{
        didSet{
            
            collectionView.dataSource = self
            collectionView.delegate = self
            
            let dataCellNib = UINib(nibName: "DataCell", bundle: .main)
            collectionView.register(dataCellNib, forCellWithReuseIdentifier: "DataCell")
            let customerCellNib = UINib(nibName: "CustomerGraphCell", bundle: .main)
            collectionView.register(customerCellNib, forCellWithReuseIdentifier: "CustomerGraphCell")
            let invoiceCellNib = UINib(nibName: "InvoiceGraphCell", bundle: .main)
            collectionView.register(invoiceCellNib, forCellWithReuseIdentifier: "InvoiceGraphCell")
            let dispatchCellNib = UINib(nibName: "DispatchMapCell", bundle: .main)
            collectionView.register(dispatchCellNib, forCellWithReuseIdentifier: "DispatchMapCell")
            
            
            
            let dashboardCellNib = UINib(nibName: "DashboardItemCell", bundle: .main)
            collectionView.register(dashboardCellNib, forCellWithReuseIdentifier: "DashboardItemCell")
            
            let headerNib = UINib(nibName: "HeaderView", bundle: .main)
            collectionView.register(headerNib, forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: "HeaderView")
        }
    }
    
    //MARK:- PROPERTIES
    
    private var sections = [
        DashboardSection(items: [
            DashboardItem(id: 50),
            DashboardItem(id: 40),
            DashboardItem(id: 30),
            DashboardItem(id: 20),
            DashboardItem(id: 10),
        ], type: .data),
        DashboardSection(items: [
            DashboardItem(id: 50),
        ], type: .customer),
        DashboardSection(items: [
            DashboardItem(id: 50),
        ], type: .invoice),
        DashboardSection(items: [
            DashboardItem(id: 50),
        ], type: .dispatch),
        DashboardSection(items: [
            DashboardItem(id: 50),
            DashboardItem(id: 40),
            DashboardItem(id: 30),
            DashboardItem(id: 20),
            DashboardItem(id: 10),
        ], type: .activity),
        DashboardSection(items: [
            DashboardItem(id: 50),
            DashboardItem(id: 40),
            DashboardItem(id: 30),
            DashboardItem(id: 20),
            DashboardItem(id: 10),
        ], type: .notifications),
    ]

}


//MARK:- DATASOURCE AND DELEGATE
extension DashboardView:UICollectionViewDataSource,UICollectionViewDelegate,UICollectionViewDelegateFlowLayout{
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        sections.count
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        sections[section].items.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let section = sections[indexPath.section]
        switch section.type {
        case .data:
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "DataCell", for: indexPath) as! DataCell
            cell.bgView.backgroundColor = .init(red: .random(in: 0.7...1), green: .random(in: 0.7...1), blue: .random(in: 0.7...1), alpha: 1)
            return cell
        case .customer:
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CustomerGraphCell", for: indexPath) as! CustomerGraphCell
            return cell
        case .invoice:
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "InvoiceGraphCell", for: indexPath) as! InvoiceGraphCell
            return cell
        case .dispatch:
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "DispatchMapCell", for: indexPath) as! DispatchMapCell
            return cell
        case .activity:
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "DashboardItemCell", for: indexPath) as! DashboardItemCell
            cell.topLineView.isHidden = indexPath.row == 0
            cell.bottomLineView.isHidden = indexPath.row == section.items.count - 1
            cell.roundView.backgroundColor = .init(red: .random(in: 0...0.5), green: .random(in: 0...0.5), blue: .random(in: 0...0.5), alpha: 1)
            return cell
        case .notifications:
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "DashboardItemCell", for: indexPath) as! DashboardItemCell
            cell.topLineView.isHidden = indexPath.row == 0
            cell.bottomLineView.isHidden = indexPath.row == section.items.count - 1
            cell.roundView.backgroundColor = .init(red: .random(in: 0...0.5), green: .random(in: 0...0.5), blue: .random(in: 0...0.5), alpha: 1)
            return cell
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        let section = sections[section]
        switch section.type{
        case .activity,.notifications:
            return 0
        default:
            return 20
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        let section = sections[section]
        switch section.type{
        case .activity,.notifications:
            return 0
        default:
            return 20
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        .init(top: 0, left: 20, bottom: 0, right: 20)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        let section = sections[indexPath.section]
        switch section.type {
        case .activity,.notifications:
            return .init(width: ez.screenWidth, height: 90)
        case .data:
            let value = ez.screenWidth * 0.5 - 10 - 20
            return .init(width: value, height: value)
        default:
            return .init(width: ez.screenWidth, height: ez.screenWidth * 0.8)
        }
        
    }
    

    
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        let headerView = collectionView.dequeueReusableSupplementaryView(ofKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: "HeaderView", for: indexPath)
        return headerView
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForHeaderInSection section: Int) -> CGSize {
        let section = sections[section]
        switch section.type{
        case .activity,.notifications:
            return .init(width: ez.screenWidth, height: 50)
        default:
            return .zero
        }
    }
}
