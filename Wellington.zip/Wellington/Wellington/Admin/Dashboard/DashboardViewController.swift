//
//  DashboardViewController.swift
//  Wellington
//
//  Created by Aqib Ali on 12/09/20.
//  Copyright © 2020 Aqib Ali. All rights reserved.
//

import UIKit
import MenuSlider
import EZSwiftExtensions



struct DashboardItem: Hashable {
    let id:Int
}

enum Section:CaseIterable{
    case data,customer,invoice,dispatch,activity,notifications
}

struct DashboardSection {
    var items:Array<DashboardItem>
    let type:Section
}






class DashboardViewController: UIViewController {
    
    
    
    //MARK:- PROPERTIES
    var menu: SideMenuViewController!
    private let imageView = UIImageView()
    private let v = UIView(frame: .init(origin: .zero, size: .init(width: 30, height: 30)))
    //MARK:- FUNCTIONS
    override func viewDidLoad() {
        super.viewDidLoad()
        
        set(title: "Dashboard")
        
        
        setUpMenu()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        showNavBar()
        setUpBarButtons()
    }
    
    private func setUpBarButtons(){
        
        setLeftBarButton(selector: #selector(menuAction),image:UIImage(systemName: "line.horizontal.3"))
        
        imageView.frame = v.bounds
        v.addSubview(imageView)
        imageView.tintColor = R.color.primaryColor()
        let config = UIImage.SymbolConfiguration(weight: .ultraLight)
        imageView.image = UIImage(systemName: "person.circle",withConfiguration: config)
        
        let btn = UIButton(frame: v.bounds)
        btn.addTarget(self, action: #selector(accountAction), for: .touchUpInside)
        v.addSubview(btn)
        
        let btnBell = UIBarButtonItem(image: UIImage(systemName: "bell"), style: .plain, target: self, action: #selector(notificationAction))
        navigationItem.rightBarButtonItems = [UIBarButtonItem(customView: v),btnBell]
    
    }
    
    
    
    //MARK:- ACTIONS
    @objc func menuAction(){
        menu.expand(onController: self)
    }
    
    @objc func accountAction(){
        if let vc = R.storyboard.profile.profileViewController(){
            navigationController?.pushViewController(vc, animated: true)
        }
    }
    @objc func notificationAction(){
        if let vc = R.storyboard.notification.notificationsViewController(){
            navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    
    
}






//MARK:- MENU SLIDER

extension DashboardViewController:SideMenuDelegate{
    @objc func homeAction(){
        
    }
    
    @objc func jobsAction(){
        if let vc = R.storyboard.job.jobsViewController(){
            navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    @objc func dispatchesAction(){
        if let vc = R.storyboard.dispatche.dispatchesViewController(){
            navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    @objc func servicesAction(){
        if let vc = R.storyboard.service.servicesViewController(){
            navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    @objc func customerAction(){
        if let vc = R.storyboard.customer.customersViewController(){
            navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    @objc func haulerAction(){
        if let vc = R.storyboard.hauler.haulersViewController(){
            navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    @objc func adminAction(){
        if let vc = R.storyboard.admin.adminsViewController(){
            navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    @objc func  managersAction(){
        if let vc = R.storyboard.manager.managersViewController(){
            navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    @objc func  driversAction(){
        if let vc = R.storyboard.driver.driversViewController(){
            navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    @objc func  trucksAction(){
        if let vc = R.storyboard.truck.trucksViewController(){
            navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    @objc func  skidSteersAction(){
        if let vc = R.storyboard.skidSteer.skidSteersViewController(){
            navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    @objc func  accountingAction(){
        if let vc = R.storyboard.accounting.accountingViewController(){
            navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    @objc func  reportAction(){
        if let vc = R.storyboard.report.reportsViewController(){
            navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    
    @objc func  logoutAction(){
        let alert = UIAlertController(title: "Are you sure to logout?", message: nil, preferredStyle: .alert)
        alert.addAction(.init(title: "Yes", style: .destructive, handler: { [weak self] _ in
            self?.logout()
        }))
        alert.addAction(.init(title: "No", style: .cancel))
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) { [weak self] in
            self?.present(alert, animated: true)
        }
        
    }
    
    private func setUpMenu(){
        
        let menuItems:[SideMenuItem] = [
            ("Overview","house",homeAction),
            ("Jobs","bag",jobsAction),
            ("Dispatctes","cube.box",dispatchesAction),
            ("Services","timer",servicesAction),
            ("Customer","person",customerAction),
            ("Hauler","person.badge.plus",haulerAction),
            ("Managers","person.2",managersAction),
            ("Drivers","person.2",driversAction),
            ("Trucks","car",trucksAction),
            ("SkidSteers","person",skidSteersAction),
            ("Accounting","creditcard",accountingAction),
            ("Reports","doc.text",reportAction),
            ("Admins","person.2",adminAction),
            ("Edit Profile","person",accountAction),
            ("Log Out","arrow.left.circle",logoutAction),
            ].map {
                
                let view = MenuItemView(menu: .init(image: UIImage(systemName: $0.1,weight: .light), title: $0.0))
                return SideMenuItemFactory.make(view: view,action: $0.2)
                
        }
        
        let header = MenuHeader()
        header.userViewModel = ProfileViewModel.shared.userViewModel
        let menuheader = SideMenuHeaderFactory.make(view: header)
        
        let menuBuild = SideMenu(menuItems: menuItems, header: menuheader)
        menu = menuBuild.build()
        menu.delegate = self
        
        
        header.imageView.set(imageFrom: ProfileViewModel.shared.userViewModel?.image){ image in
            self.v.layer.cornerRadius = 15
            self.v.layer.borderColor = R.color.primaryColor()?.cgColor
            self.v.layer.borderWidth = 1
            self.v.clipsToBounds = true
            self.imageView.image = image
        }
    }
    
}


