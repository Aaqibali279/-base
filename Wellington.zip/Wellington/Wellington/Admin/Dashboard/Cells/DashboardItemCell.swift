//
//  DashboardItemCell.swift
//  Wellington
//
//  Created by Aqib Ali on 13/09/20.
//  Copyright © 2020 Aqib Ali. All rights reserved.
//

import UIKit

class DashboardItemCell: UICollectionViewCell {
    
    //MARK:- OUTLETS
    @IBOutlet weak var topLineView:UIView!
    @IBOutlet weak var bottomLineView:UIView!
    @IBOutlet weak var roundView:UIView!
    
}
