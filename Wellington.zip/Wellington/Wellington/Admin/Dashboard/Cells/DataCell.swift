//
//  DataCell.swift
//  Wellington
//
//  Created by Aqib Ali on 13/09/20.
//  Copyright © 2020 Aqib Ali. All rights reserved.
//

import UIKit
import IBAnimatable

class DataCell: UICollectionViewCell {

    //MARK:- OUTLETS
    @IBOutlet weak var bgView: AnimatableView!
    
}
