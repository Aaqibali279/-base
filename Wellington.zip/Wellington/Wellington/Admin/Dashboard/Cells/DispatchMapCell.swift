//
//  DispatchMapCell.swift
//  Wellington
//
//  Created by Aqib Ali on 13/09/20.
//  Copyright © 2020 Aqib Ali. All rights reserved.
//

import UIKit

class DispatchMapCell: UICollectionViewCell {


}
