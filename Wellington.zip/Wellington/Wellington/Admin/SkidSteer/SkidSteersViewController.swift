//
//  ServicesViewController.swift
//  Wellington
//
//  Created by Aqib Ali on 12/09/20.
//  Copyright © 2020 Aqib Ali. All rights reserved.
//

import UIKit

class SkidSteersViewController: UIViewController {
    
    //MARK:- OUTLETS
    @IBOutlet weak var tableView: UITableView!{
        didSet{
            
            let nib = UINib(nibName: "SkidSteerCell", bundle: .main)
            tableView.register(nib, forCellReuseIdentifier: "SkidSteerCell")
            
            tableView.delegate = dataSource
            tableView.dataSource = dataSource
            tableView.bounces = false
            
        }
    }
    
    //MARK:- PROPERTIES
    private let skidSteersViewModel = SkidSteersViewModel()
    private lazy var dataSource = TableViewDelegateDatasource<SkidSteerViewModel>(heightForHeader: 50, cellForRowAt: { [unowned self] (viewModel, indexPath) -> UITableViewCell in
        let cell = self.tableView.dequeueReusableCell(withIdentifier: "SkidSteerCell",for:indexPath) as! SkidSteerCell
        cell.skidSteerViewModel = viewModel
        return cell
    },headerForSection: { (section) -> UIView in
        SearchHeaderView(delegate: self)
    },loadMoreData: { [weak self] offset in
        self?.getSkidSteers(offset: offset)
    })
    
    //MARK:- FUNCTIONS
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        set(title: "SkidSteers")
        setBackButton()
        getSkidSteers()
    }
    
    //MARK:- API's
    private func getSkidSteers(offset:Int = 0){
        tableView.tableFooterView = indicatorFooterView
        skidSteersViewModel.skidSteers(offSet: offset) { [unowned self] (items) in
            self.dataSource.items.append(contentsOf: items)
            self.tableView.tableFooterView = nil
            self.tableView.reloadData()
        }
    }
    
}


extension SkidSteersViewController:SearchHeaderViewDelegate{

    func search(from text: String) {
        dataSource.items = skidSteersViewModel.items.filter{ $0.companyName.lowercased().contains(text) || $0.truckNumber.lowercased().contains(text) || $0.chaseNumber.lowercased().contains(text) }
        tableView.reloadData()
    }
    
    func reloadAll() {
        dataSource.items = skidSteersViewModel.items
        tableView.reloadData()
    }
    
    func add() {
        showSnackBar(message: "Add Tapped")
    }
    
    
    
}
