//
//  SkidSteersViewModel.swift
//  Wellington
//
//  Created by Aqib Ali on 20/09/20.
//  Copyright © 2020 Aqib Ali. All rights reserved.
//

import Foundation


struct SkidSteer:Decodable {
    let id:Int
    let created_by:Int?
    let vehicle_type:Int?
    let company_name:String?
    let truck_number:String?
    let chaase_number:String?
    let killometer:String?
    let capacity:Int?
    let document:String?
    let status:Int?
    let created_at:String?
    let user:UserModel?
}


struct SkidSteerViewModel {
    
    let companyName:String
    let kilometer:String
    let truckNumber:String
    let chaseNumber:String
    let capacity:String
    let document:String?
    let skidSteer:SkidSteer
    let userViewModel:UserViewModel
    
    init(skidSteer:SkidSteer) {
        
        companyName = skidSteer.company_name ?? NOT_AVAILABLE
        truckNumber = skidSteer.truck_number ?? NOT_AVAILABLE
        chaseNumber = skidSteer.chaase_number ?? NOT_AVAILABLE
        document = skidSteer.document
        userViewModel = UserViewModel(user: skidSteer.user)
        
        if let kilometers = skidSteer.killometer{ kilometer = "\(kilometers) KM's" } else { kilometer = NOT_AVAILABLE }
        if let capacity = skidSteer.capacity { self.capacity = "\(capacity)" } else { capacity = NOT_AVAILABLE }
        
        self.skidSteer = skidSteer
    }
}


class SkidSteersViewModel :Pagination {
    var isPaginating: Bool = false
    
    
    var items = Array<SkidSteerViewModel>()
    
    
    func skidSteers(offSet:Int,success: @escaping (Array<SkidSteerViewModel>) -> ()){
        let params = [
            "offset": offSet,
            "take": 10
        ]
        
        guard !isPaginating else{
            return
        }
        
        isPaginating = true
        if offSet == 0{
            items.removeAll()
        }
        
        NetworkManager.instance.request(endPoint: .skidsteers, method: .get, parameters: params, showIndicator: offSet == 0, loadingText: "loading drivers") { [unowned self] (result:NetworkResult<Array<SkidSteer>>) in
            self.isPaginating = false
            switch result{
            case .success(let data):
                let list = data ?? []
                let viewModels = list.map{SkidSteerViewModel(skidSteer: $0)}
                self.items.append(contentsOf: viewModels)
                success(viewModels)
            case .failure(_):
                break
            }
        }
    }
}
