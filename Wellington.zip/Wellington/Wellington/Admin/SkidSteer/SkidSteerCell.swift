//
//  SkidSteerCell.swift
//  Wellington
//
//  Created by Aqib Ali on 20/09/20.
//  Copyright © 2020 Aqib Ali. All rights reserved.
//

import UIKit

class SkidSteerCell: UITableViewCell {

    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var vehicleNumberLabel: UILabel!
    @IBOutlet weak var chaseNumberLabel: UILabel!
    @IBOutlet weak var distanceLabel: UILabel!
    @IBOutlet weak var capacityLabel: UILabel!
    @IBOutlet weak var btnEdit: UIButton!
    @IBOutlet weak var btnDelete: UIButton!
    
    
    var skidSteerViewModel:SkidSteerViewModel?{
        didSet{
            nameLabel.text = skidSteerViewModel?.companyName
            vehicleNumberLabel.text = skidSteerViewModel?.truckNumber
            chaseNumberLabel.text = skidSteerViewModel?.chaseNumber
            distanceLabel.text = skidSteerViewModel?.kilometer
            capacityLabel.text = skidSteerViewModel?.capacity
        }
    }
    
}
