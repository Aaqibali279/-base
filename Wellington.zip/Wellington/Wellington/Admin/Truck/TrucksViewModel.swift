//
//  TrucksViewModel.swift
//  Wellington
//
//  Created by Aqib Ali on 20/09/20.
//  Copyright © 2020 Aqib Ali. All rights reserved.
//

import Foundation


struct Truck:Decodable {
    let id:Int
    let created_by:Int?
    let vehicle_type:Int?
    let company_name:String?
    let truck_number:String?
    let chaase_number:String?
    let killometer:String?
    let capacity:Int?
    let document:String?
    let status:Int?
    let created_at:String?
    let assigned_job_row_action_count:Int?
}

struct TruckViewModel {
    
    let companyName:String
    let kilometer:String
    let truckNumber:String
    let chaseNumber:String
    let capacity:String
    let document:String?
    let truck:Truck
    
    init(truck:Truck) {
        
        companyName = truck.company_name ?? NOT_AVAILABLE
        truckNumber = truck.truck_number ?? NOT_AVAILABLE
        chaseNumber = truck.chaase_number ?? NOT_AVAILABLE
        document = truck.document
        
        if let kilometers = truck.killometer{ kilometer = "\(kilometers) KM's" } else { kilometer = NOT_AVAILABLE }
        if let capacity = truck.capacity { self.capacity = "\(capacity)" } else { capacity = NOT_AVAILABLE }
        
        self.truck = truck
    }
}

class TrucksViewModel:Pagination {
    
    var isPaginating: Bool = false
    
    var items = Array<TruckViewModel>()
    
    func vehicles(offSet:Int,success: @escaping (Array<TruckViewModel>) -> ()){
        
        let params = [
            "offset": offSet,
            "take": 10
        ]
        
        guard !isPaginating else{
            return
        }
        
        isPaginating = true
        if offSet == 0{
            items.removeAll()
        }
        
        NetworkManager.instance.request(endPoint: .vehicles, method: .post, parameters: params, showIndicator: offSet == 0, loadingText: "loading trucks") { [unowned self] (result:NetworkResult<Array<Truck>>) in
            
            
            self.isPaginating = false
            
            switch result{
            case .success(let data):
                let list = data ?? []
                let viewModels = list.map{TruckViewModel(truck: $0)}
                self.items.append(contentsOf: viewModels)
                success(viewModels)
            case .failure(_):
                break
            }
        }
    }
}

