//
//  TruckCell.swift
//  Wellington
//
//  Created by Aqib Ali on 13/09/20.
//  Copyright © 2020 Aqib Ali. All rights reserved.
//

import UIKit

class TruckCell: UITableViewCell {

    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var vehicleNumberLabel: UILabel!
    @IBOutlet weak var chaseNumberLabel: UILabel!
    @IBOutlet weak var distanceLabel: UILabel!
    @IBOutlet weak var capacityLabel: UILabel!
    @IBOutlet weak var btnEdit: UIButton!
    @IBOutlet weak var btnDelete: UIButton!
    
    
    var truckViewModel:TruckViewModel?{
        didSet{
            nameLabel.text = truckViewModel?.companyName
            vehicleNumberLabel.text = truckViewModel?.truckNumber
            chaseNumberLabel.text = truckViewModel?.chaseNumber
            distanceLabel.text = truckViewModel?.kilometer
            capacityLabel.text = truckViewModel?.capacity
        }
    }
}
