//
//  ServicesViewController.swift
//  Wellington
//
//  Created by Aqib Ali on 12/09/20.
//  Copyright © 2020 Aqib Ali. All rights reserved.
//

import UIKit

class ReportsViewController: UIViewController {
    
    //MARK:- OUTLETS
    @IBOutlet weak var tableView: UITableView!{
        didSet{
            tableView.delegate = dataSource
            tableView.dataSource = dataSource
            tableView.bounces = false
        }
    }
    
    //MARK:- PROPERTIES
    private lazy var dataSource = TableViewDelegateDatasource<Int>(heightForHeader: 50, cellForRowAt: { (viewModel, indexPath) -> UITableViewCell in
        return UITableViewCell(style: .default, reuseIdentifier: "")
    },headerForSection: { (section) -> UIView in
        SearchHeaderView(delegate: self)
    },loadMoreData: { [weak self] offset in
        
    })
    
    //MARK:- FUNCTIONS
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        set(title: "Reports")
        setBackButton()
    }
    
}



extension ReportsViewController:SearchHeaderViewDelegate{
    func reloadAll() {
        
    }
    
    func search(from text: String) {
        print(text)
    }
    
    func add() {
        showSnackBar(message: "Add Tapped")
    }
    
    
}
