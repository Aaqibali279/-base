//
//  DriversViewModel.swift
//  Wellington
//
//  Created by Aqib Ali on 17/09/20.
//  Copyright © 2020 Aqib Ali. All rights reserved.
//

import Foundation


struct Driver:Decodable {
    let id:Int
    let user_id:Int
    let driver_type:Int?
    let driver_licence:String?
    let salary_type:Int?
    let driver_salary:Int?
    let document:String?
    let status:Int?
}

struct DriverViewModel {
    
    let name:String
    let phone:String
    let email:String
    let address:String
    let driverLicence:String
    let salary:String
    let distance:String
    let amount:String
    let image:String?
    let driver:Driver?
    
    init(user:UserModel){
        if let firstname = user.first_name,let lastname = user.last_name{
            name = firstname + " " + lastname
        }else{ name = NOT_AVAILABLE }
        phone = user.phone ?? NOT_AVAILABLE
        email = user.email ?? NOT_AVAILABLE
        var value = ""
        if let address = user.address{
            value = address
        }
        if let city = user.city{
            value += " \(city)"
        }
        if let state = user.state{
            value += " \(state)"
        }
        if let country = user.country{
            value += " \(country)"
        }
        if let pincode = user.zip_code{
            value += " \(pincode)"
        }
        address = value
        driverLicence = user.driver?.driver_licence ?? NOT_AVAILABLE
        if let amount = user.driver?.driver_salary{
            salary = "$" + String(amount)
        }else{ salary = NOT_AVAILABLE }
        distance = NOT_AVAILABLE
        amount = NOT_AVAILABLE
        image = nil
        self.driver = user.driver
    }
}



class DriversViewModel:Pagination {
    var isPaginating: Bool = false
    
    
    var items = Array<DriverViewModel>()
    
    
    func drivers(offSet:Int,success: @escaping (Array<DriverViewModel>) -> ()){
        let params = [
            "offset": offSet,
            "take": 10
        ]
        
        guard !isPaginating else{
            return
        }
        
        isPaginating = true
        if offSet == 0{
            items.removeAll()
        }
        
        NetworkManager.instance.request(endPoint: .drivers, method: .post, parameters: params, showIndicator: offSet == 0, loadingText: "loading drivers") { [unowned self] (result:NetworkResult<Array<UserModel>>) in
            self.isPaginating = false
            switch result{
            case .success(let data):
                let list = data ?? []
                let viewModels = list.map{DriverViewModel(user: $0)}
                self.items.append(contentsOf: viewModels)
                success(viewModels)
            case .failure(_):
                break
            }
        }
    }
}
