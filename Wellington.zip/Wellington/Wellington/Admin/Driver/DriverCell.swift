//
//  DriverCell.swift
//  Wellington
//
//  Created by Aqib Ali on 12/09/20.
//  Copyright © 2020 Aqib Ali. All rights reserved.
//

import UIKit
import IBAnimatable

class DriverCell: UITableViewCell {

    @IBOutlet weak var iv: AnimatableImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var phoneLabel: UILabel!
    @IBOutlet weak var emailLabel: UILabel!
    @IBOutlet weak var addressLabel: UILabel!
    @IBOutlet weak var licenseLabel: UILabel!
    @IBOutlet weak var salaryLabel: UILabel!
    @IBOutlet weak var distanceLabel: UILabel!
    @IBOutlet weak var rateLabel: UILabel!
    
    
    var driverViewModel:DriverViewModel?{
        didSet{
            nameLabel.text = driverViewModel?.name
            phoneLabel.text = driverViewModel?.phone
            emailLabel.text = driverViewModel?.email
            addressLabel.text = driverViewModel?.address
            licenseLabel.text = driverViewModel?.driverLicence
            salaryLabel.text = driverViewModel?.salary
            distanceLabel.text = driverViewModel?.distance
            rateLabel.text = driverViewModel?.amount
            iv.set(imageFrom: driverViewModel?.image)
        }
    }
}
