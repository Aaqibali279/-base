//
//  ServicesViewController.swift
//  Wellington
//
//  Created by Aqib Ali on 12/09/20.
//  Copyright © 2020 Aqib Ali. All rights reserved.
//

import UIKit

class DriversViewController: UIViewController {
    
    //MARK:- OUTLETS
    @IBOutlet weak var tableView: UITableView!{
        didSet{
            let nib = UINib(nibName: "DriverCell", bundle: .main)
            tableView.register(nib, forCellReuseIdentifier: "DriverCell")
            tableView.delegate = dataSource
            tableView.dataSource = dataSource
            tableView.bounces = false
        }
    }
    
    
    //MARK:- PROPERTIES
    private lazy var dataSource = TableViewDelegateDatasource<DriverViewModel>(heightForHeader: 50, cellForRowAt: { [unowned self] (viewModel, indexPath) -> UITableViewCell in
        let cell = self.tableView.dequeueReusableCell(withIdentifier: "DriverCell",for:indexPath) as! DriverCell
        cell.driverViewModel = viewModel
        return cell
        },headerForSection: { (section) -> UIView in
            SearchHeaderView(delegate: self)
    },loadMoreData: { [weak self] offset in
        self?.getDrivers(offSet: offset)
    })
    
    private let driversViewModel = DriversViewModel()
    
    //MARK:- FUNCTIONS
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        set(title: "Drivers")
        setBackButton()
        getDrivers()
    }
    
    private func getDrivers(offSet:Int = 0){
        tableView.tableFooterView = indicatorFooterView
        driversViewModel.drivers(offSet:offSet) { [unowned self] drivers in
            self.tableView.tableFooterView = nil
            self.dataSource.items.append(contentsOf: drivers)
            self.tableView.reloadData()
        }
    }
    
}



extension DriversViewController:SearchHeaderViewDelegate{
    func reloadAll() {
        dataSource.items = driversViewModel.items
        tableView.reloadData()
    }
    
    func search(from text: String) {
        dataSource.items = driversViewModel.items.filter{$0.name.lowercased().contains(text) || $0.email.contains(text)}
        tableView.reloadData()
    }
    
    func add() {
        showSnackBar(message: "Add Tapped")
    }
    
    
}
