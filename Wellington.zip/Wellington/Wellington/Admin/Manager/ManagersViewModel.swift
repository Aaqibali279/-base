//
//  ManagersViewModel.swift
//  Wellington
//
//  Created by Aqib Ali on 15/09/20.
//  Copyright © 2020 Aqib Ali. All rights reserved.
//

import Foundation

struct Manager:Decodable {
    let id:Int
    let first_name:String?
    let last_name:String?
    let email:String?
    let phone:String?
    let address:String?
    let city:String?
    let state:String?
    let country:String?
    let zip_code:String?
    let user_image:String?
    let role_id:Int?
    let is_confirmed:Int?
    let is_active:Int?
    let manager_details:ManagerDetails?
}


struct ManagerDetails:Decodable {
    let id:Int?
    let user_id:Int?
    let salary:Int?
    let identification_number:String?
    let joining_date:String?
    let releaving_date:String?
    let document:String?
    let created_at:String?
    let updated_at:String?
}


struct ManagerViewModel {
    
    let image:String
    let name:String
    let phone:String
    let email:String
    let address:String
    let identity:String
    let salary:String
    
    init(manager:Manager?) {
        image = manager?.user_image ?? ""
        name = (manager?.first_name ?? "") + " " + (manager?.last_name ?? "")
        phone = manager?.phone ?? NOT_AVAILABLE
        email = manager?.email ?? NOT_AVAILABLE
        
        var address = ""
        if let village = manager?.address{
            address += village
        }
        
        if let city = manager?.city{
            address = address + " " + city
        }
        
        if let state = manager?.state{
            address = address + " " + state
        }
        
        if let country = manager?.country{
            address = address + " " + country
        }
        
        self.address = !address.isEmpty ? address : NOT_AVAILABLE
        
        identity = manager?.manager_details?.identification_number ?? NOT_AVAILABLE
        if let amount = manager?.manager_details?.salary{
            salary = String(amount)
        }else{
            salary = NOT_AVAILABLE
        }
        
    }
}


class ManagersViewModel:Pagination {
    var isPaginating: Bool = false
    
    var items = Array<ManagerViewModel>()
    
    func managers(offSet:Int,take:Int = 10,success: @escaping (Array<ManagerViewModel>) -> ()){
        let params = [
            "offset": "\(offSet)",
            "take": "\(take)"
        ]
        
        if offSet == 0{
            items.removeAll()
        }
        
        guard !isPaginating else {return}
        isPaginating = true
        NetworkManager.instance.request(endPoint: .managers, method: .post, parameters: params, showIndicator: offSet == 0, loadingText: "loading managers") { [unowned self] (result:NetworkResult<Array<Manager>>) in
            self.isPaginating = false
            switch result{
            case .success(let data):
                let list = data ?? []
                let viewModels = list.map{ManagerViewModel(manager: $0)}
                self.items.append(contentsOf: viewModels)
                success(viewModels)
            case .failure(_):
                break
            }
        }
    }
}
