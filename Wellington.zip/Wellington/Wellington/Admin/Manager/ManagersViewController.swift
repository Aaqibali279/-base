//
//  ServicesViewController.swift
//  Wellington
//
//  Created by Aqib Ali on 12/09/20.
//  Copyright © 2020 Aqib Ali. All rights reserved.
//

import UIKit

class ManagersViewController: UIViewController {
    
    //MARK:- OUTLETS
    @IBOutlet weak var tableView: UITableView!{
        didSet{
            let nib = UINib(nibName: "ManagerCell", bundle: .main)
            tableView.register(nib, forCellReuseIdentifier: "ManagerCell")
            tableView.delegate = dataSource
            tableView.dataSource = dataSource
            tableView.bounces = false
        }
    }
    
    
    //MARK:- PROPERTIES
    private lazy var dataSource = TableViewDelegateDatasource<ManagerViewModel>(heightForHeader: 50, cellForRowAt: { [unowned self] (viewModel, indexPath) -> UITableViewCell in
        let cell = self.tableView.dequeueReusableCell(withIdentifier: "ManagerCell",for:indexPath) as! ManagerCell
        cell.managerViewModel = viewModel
        return cell
        },headerForSection: { (section) -> UIView in
            SearchHeaderView(delegate: self)
    },loadMoreData: { [weak self] offset in
        self?.getManagers(offSet: offset)
    })
    private var offSet = 0
    private let managersViewModel = ManagersViewModel()
    
    //MARK:- FUNCTIONS
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        set(title: "Managers")
        setBackButton()
        offSet = 0
        getManagers(offSet: 0)
    }
    
    
    //MARK:- API's
    private func getManagers(offSet: Int){
        tableView.tableFooterView = indicatorFooterView
        managersViewModel.managers(offSet: offSet) { [unowned self] managers in
            self.tableView.tableFooterView = nil
            self.dataSource.items.append(contentsOf: managers)
            self.tableView.reloadData()
        }
    }
}



extension ManagersViewController:SearchHeaderViewDelegate{
    func reloadAll() {
        dataSource.items = managersViewModel.items
        tableView.reloadData()
    }
    
    func search(from text: String) {
        dataSource.items = managersViewModel.items.filter{ $0.name.lowercased().contains(text) || $0.email.lowercased().contains(text) }
        tableView.reloadData()
    }
    
    func add() {
        showSnackBar(message: "Add Tapped")
    }
    
    
}
