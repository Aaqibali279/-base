//
//  ManagerCell.swift
//  Wellington
//
//  Created by Aqib Ali on 13/09/20.
//  Copyright © 2020 Aqib Ali. All rights reserved.
//

import UIKit

class ManagerCell: UITableViewCell {

   //MARK:- OUTLETS
    @IBOutlet weak var iv:UIImageView!
    @IBOutlet weak var nameLabel:UILabel!
    @IBOutlet weak var phoneLabel:UILabel!
    @IBOutlet weak var emailLabel:UILabel!
    @IBOutlet weak var addressLabel:UILabel!
    @IBOutlet weak var identityLabel:UILabel!
    @IBOutlet weak var salaryLabel:UILabel!
    
    @IBOutlet weak var btnEdit:UIButton!
    @IBOutlet weak var btnDelete:UIButton!
    
    //MARK:- PROPERTIES
    var managerViewModel:ManagerViewModel?{
        didSet{
            nameLabel.text = managerViewModel?.name
            phoneLabel.text = managerViewModel?.phone
            emailLabel.text = managerViewModel?.email
            addressLabel.text = managerViewModel?.address
            identityLabel.text = managerViewModel?.address
            salaryLabel.text = managerViewModel?.salary
            iv.set(imageFrom: managerViewModel?.image)
        }
    }
}
