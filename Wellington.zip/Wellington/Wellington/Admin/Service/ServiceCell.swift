//
//  ServiceCell.swift
//  Wellington
//
//  Created by Aqib Ali on 12/09/20.
//  Copyright © 2020 Aqib Ali. All rights reserved.
//

import UIKit

class ServiceCell: UITableViewCell {

    //MARK:- OUTLETS
    @IBOutlet weak var iv:UIImageView!
    @IBOutlet weak var nameLabel:UILabel!
    @IBOutlet weak var priceLabel:UILabel!
    @IBOutlet weak var slotTypeLabel:UILabel!
    @IBOutlet weak var timeSlotLabel:UILabel!
    @IBOutlet weak var moreLabel:UILabel!
    
    var row = 0
    
    var serviceViewModel:ServiceViewModel!{
        didSet{
            nameLabel.text = "#\(row)" + " - " + serviceViewModel.title
            priceLabel.text = serviceViewModel.price
            timeSlotLabel.text = serviceViewModel.slot
            slotTypeLabel.text = serviceViewModel.slotType
            moreLabel.text = serviceViewModel.more
            moreLabel.isHidden = serviceViewModel.more == nil
            iv.set(imageFrom: serviceViewModel?.image)
        }
    }
    
}
