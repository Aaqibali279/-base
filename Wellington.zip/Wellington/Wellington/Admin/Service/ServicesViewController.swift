//
//  ServicesViewController.swift
//  Wellington
//
//  Created by Aqib Ali on 12/09/20.
//  Copyright © 2020 Aqib Ali. All rights reserved.
//

import UIKit

class ServicesViewController: UIViewController {
    
    //MARK:- OUTLETS
    @IBOutlet weak var tableView: UITableView!{
        didSet{
            let nib = UINib(nibName: "ServiceCell", bundle: .main)
            tableView.register(nib, forCellReuseIdentifier: "ServiceCell")
            tableView.delegate = dataSource
            tableView.dataSource = dataSource
            tableView.bounces = false
        }
    }
    
    
    //MARK:- PROPERTIES
    private lazy var dataSource = TableViewDelegateDatasource<ServiceViewModel>(heightForHeader: 50, cellForRowAt: { [unowned self] (viewModel, indexPath) -> UITableViewCell in
        let cell = self.tableView.dequeueReusableCell(withIdentifier: "ServiceCell",for:indexPath) as! ServiceCell
        cell.row = indexPath.row + 1
        cell.serviceViewModel = viewModel
        return cell
        },headerForSection: { (section) -> UIView in
            SearchHeaderView(delegate: self)
    },loadMoreData: { [weak self] offset in
        self?.getServices(offSet: offset)
    })
    private let servicesViewModel = ServicesViewModel()
    
    //MARK:- FUNCTIONS
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        set(title: "Services")
        setBackButton()
        getServices()
    }
    
    
    private func getServices(offSet:Int = 0){
        tableView.tableFooterView = indicatorFooterView
        servicesViewModel.services(offSet:offSet) { [unowned self] services in
            self.tableView.tableFooterView = nil
            self.dataSource.items.append(contentsOf: services)
            self.tableView.reloadData()
        }
    }
    
}


extension ServicesViewController:SearchHeaderViewDelegate{
    func reloadAll() {
        dataSource.items = servicesViewModel.items
        tableView.reloadData()
    }
    
    func search(from text: String) {
        dataSource.items = servicesViewModel.items.filter{$0.title.lowercased().contains(text)}
        tableView.reloadData()
    }
    
    func add() {
        showSnackBar(message: "Add Tapped")
    }
    
    
}
