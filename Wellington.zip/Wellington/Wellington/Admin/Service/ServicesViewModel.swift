//
//  ServicesViewModel.swift
//  Wellington
//
//  Created by Aqib Ali on 16/09/20.
//  Copyright © 2020 Aqib Ali. All rights reserved.
//

import Foundation

struct Service:Decodable {
    let id:Int
    let service_name:String?
    let price:Int?
    let description:String?
    let service_type:Int
    let service_image:String?
    let service_for:Int
    let slot_type:String?
    let slot_time:String?
    let created_at:String?
    let updated_at:String?
    let deleted_at:String?
    let timeSlots:Array<TimeSlot>?
}
    
    
struct TimeSlot:Decodable {
    let id:Int
    let slot_type:Int
    let slot_start:String?
    let slot_end:String?
}


struct ServiceViewModel {
    
    let title:String
    let price:String
    let slotType:String
    let slot:String
    let more:String?
    let image:String?
    let service:Service?
    
    init(service:Service?) {
        title = service?.service_name ?? NOT_AVAILABLE
        slotType = "Morning"
        image = service?.service_image
        self.service = service
        
        if let amount = service?.price{ price = "$" + String(amount) }else { price = NOT_AVAILABLE }
        
        if let timeSlots = service?.timeSlots, let timeSlot = timeSlots.first, let start = timeSlot.slot_start,let end = timeSlot.slot_end{
            slot = start + " - " + end
            more = "+\(timeSlots.count)"
        }else{
            more = nil
            slot = NOT_AVAILABLE
        }
        
    }
}


class ServicesViewModel:Pagination {
    
    var isPaginating: Bool = false
    
    var items = Array<ServiceViewModel>()
    
    func services(offSet:Int,success: @escaping (Array<ServiceViewModel>) -> ()){
        
        let params = [
            "offset": offSet,
            "take": 10
        ]
        
        guard !isPaginating else{
            return
        }
        
        isPaginating = true
        if offSet == 0{
            items.removeAll()
        }
        
        NetworkManager.instance.request(endPoint: .services, method: .post, parameters: params, showIndicator: offSet == 0, loadingText: "loading  services") { [unowned self] (result:NetworkResult<Array<Service>>) in
            
            
            self.isPaginating = false
            
            switch result{
            case .success(let data):
                let list = data ?? []
                let viewModels = list.map{ServiceViewModel(service: $0)}
                self.items.append(contentsOf: viewModels)
                success(viewModels)
            case .failure(_):
                break
            }
        }
    }
}
