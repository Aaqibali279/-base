//
//  HaulerCell.swift
//  Wellington
//
//  Created by Aqib Ali on 12/09/20.
//  Copyright © 2020 Aqib Ali. All rights reserved.
//

import UIKit
import IBAnimatable

class HaulerCell: UITableViewCell {

    @IBOutlet weak var iv: AnimatableImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var phoneLabel: UILabel!
    @IBOutlet weak var emailLabel: UILabel!
    @IBOutlet weak var addressLabel: UILabel!
    
    
    var haulerViewModel:HaulerViewModel?{
        didSet{
            nameLabel.text = haulerViewModel?.name
            phoneLabel.text = haulerViewModel?.phone
            emailLabel.text = haulerViewModel?.email
            addressLabel.text = haulerViewModel?.address
        }
    }
}
