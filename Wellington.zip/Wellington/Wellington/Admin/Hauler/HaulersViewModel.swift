//
//  HaulersViewModel.swift
//  Wellington
//
//  Created by Aqib Ali on 17/09/20.
//  Copyright © 2020 Aqib Ali. All rights reserved.
//

import Foundation



struct HaulerViewModel {
    
    let name:String
    let phone:String
    let email:String
    let address:String
    let hauler:UserModel
    
    init(hauler:UserModel) {
        if let firstname = hauler.first_name,let lastname = hauler.last_name{ name = firstname + " " + lastname }else{ name = NOT_AVAILABLE }
        phone = hauler.phone ?? NOT_AVAILABLE
        email = hauler.email ?? NOT_AVAILABLE
        var value = ""
        if let address = hauler.address{
            value = address
        }
        if let city = hauler.city{
            value += " \(city)"
        }
        if let state = hauler.state{
            value += " \(state)"
        }
        if let country = hauler.country{
            value += " \(country)"
        }
        if let pincode = hauler.zip_code{
            value += " \(pincode)"
        }
        address = value
        self.hauler = hauler
    }
}


class HaulersViewModel:Pagination {
    
    var isPaginating: Bool = false

    var items = Array<HaulerViewModel>()
    
    func haulers(offSet:Int,success: @escaping (Array<HaulerViewModel>) -> ()){
        
        let params = [
            "offset": offSet,
            "take": 10
        ]
        
        guard !isPaginating else{
            return
        }
        
        isPaginating = true
        if offSet == 0{
            items.removeAll()
        }
        
        NetworkManager.instance.request(endPoint: .haulers, method: .post, parameters: params, showIndicator: offSet == 0, loadingText: "loading haulers") { [unowned self] (result:NetworkResult<Array<UserModel>>) in
            
            self.isPaginating = false
            
            switch result{
            case .success(let data):
                let haulers = data ?? []
                let viewModels = haulers.map{HaulerViewModel(hauler: $0)}
                self.items.append(contentsOf: viewModels)
                success(viewModels)
            case .failure(_):
                break
            }
        }
    }
}
