//
//  ServicesViewController.swift
//  Wellington
//
//  Created by Aqib Ali on 12/09/20.
//  Copyright © 2020 Aqib Ali. All rights reserved.
//

import UIKit

class HaulersViewController: UIViewController {
    
    //MARK:- OUTLETS
    @IBOutlet weak var tableView: UITableView!{
        didSet{
            let nib = UINib(nibName: "HaulerCell", bundle: .main)
            tableView.register(nib, forCellReuseIdentifier: "HaulerCell")
            tableView.delegate = dataSource
            tableView.dataSource = dataSource
            tableView.bounces = false
        }
    }
    
    
    //MARK:- PROPERTIES
    private lazy var dataSource = TableViewDelegateDatasource<HaulerViewModel>(heightForHeader: 50, cellForRowAt: { [unowned self] (viewModel, indexPath) -> UITableViewCell in
        let cell = self.tableView.dequeueReusableCell(withIdentifier: "HaulerCell",for:indexPath) as! HaulerCell
        cell.haulerViewModel = viewModel
        return cell
        },headerForSection: { (section) -> UIView in
            SearchHeaderView(delegate: self)
    },loadMoreData: { [weak self] offset in
        self?.getHaulers(offSet: offset)
    })
    
    private let haulersViewModel = HaulersViewModel()
    
    //MARK:- FUNCTIONS
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        set(title: "Haulers")
        setBackButton()
        getHaulers()
    }
    
    private func getHaulers(offSet:Int = 0){
        tableView.tableFooterView = indicatorFooterView
        haulersViewModel.haulers(offSet:offSet) { [unowned self] haulers in
            self.tableView.tableFooterView = nil
            self.dataSource.items.append(contentsOf: haulers)
            self.tableView.reloadData()
        }
    }
    
}


extension HaulersViewController:SearchHeaderViewDelegate{
    func reloadAll() {
        dataSource.items = haulersViewModel.items
        tableView.reloadData()
    }
    
    func search(from text: String) {
        dataSource.items = haulersViewModel.items.filter{$0.name.lowercased().contains(text) || $0.email.contains(text)}
        tableView.reloadData()
    }
    
    func add() {
        showSnackBar(message: "Add Tapped")
    }
    
    
}
