//
//  JobsViewController.swift
//  Wellington
//
//  Created by Aqib Ali on 12/09/20.
//  Copyright © 2020 Aqib Ali. All rights reserved.
//

import UIKit

class JobsViewController: UIViewController {

    //MARK:- OUTLETS
    @IBOutlet weak var tableView: UITableView!{
        didSet{
            tableView.delegate = dataSource
            tableView.dataSource = dataSource
            tableView.bounces = false
        }
    }
    
    
    //MARK:- PROPERTIES
    private let jobssViewModel = JobsViewModel()
    
    private lazy var dataSource = TableViewDelegateDatasource<JobViewModel>(heightForHeader: 50, cellForRowAt: { [unowned self] (viewModel, indexPath) -> UITableViewCell in
        let cell = UITableViewCell(style: .default, reuseIdentifier: "")
        cell.textLabel?.text = "#JOB\(indexPath.row + 1)"
        cell.detailTextLabel?.text = viewModel.service.title
        return cell
        },headerForSection: { (section) -> UIView in
            SearchHeaderView(delegate: self)
    },loadMoreData: { [weak self] offset in
        self?.getJobs(offset: offset)
    })
    
    //MARK:- FUNCTIONS
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    override func viewWillAppear(_ animated: Bool) {
        set(title: "Jobs")
        setBackButton()
        getJobs()
    }
    
    //MARK:- API's
    private func getJobs(offset:Int = 0){
        tableView.tableFooterView = indicatorFooterView
        jobssViewModel.jobs(offSet: offset) { [unowned self] (items) in
            self.dataSource.items.append(contentsOf: items)
            self.tableView.tableFooterView = nil
            self.tableView.reloadData()
        }
    }

}



extension JobsViewController:SearchHeaderViewDelegate{
    func search(from text: String) {
        dataSource.items = jobssViewModel.items.filter{ $0.service.title.lowercased().contains(text) }
        tableView.reloadData()
    }
    
    func reloadAll() {
        dataSource.items = jobssViewModel.items
        tableView.reloadData()
    }
    
    func add() {
        showSnackBar(message: "Add Tapped")
    }
    
    
}





















