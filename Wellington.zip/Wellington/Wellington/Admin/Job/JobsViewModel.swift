//
//  JobsViewModel.swift
//  Wellington
//
//  Created by Aqib Ali on 20/09/20.
//  Copyright © 2020 Aqib Ali. All rights reserved.
//

import Foundation

struct Job:Decodable {
    let id:Int
    let job_created_by:Int?
    let customer_id:Int?
    let farm_id:Int?
    let service_id:Int?
    let time_slots_id:Int?
    let job_providing_date:String?
    let weight:Int?
    let is_repeating_job:Int
    let amount:Int?
    let payment_mode:Int?
    let job_status:Int?
    let payment_status:Int?
    let quick_book:Int?
    let truck_id:Int?
    let truck_driver_id:Int?
    let skidsteer_id:Int?
    let skidsteer_driver_id:Int?
    let created_at:String?
    let customer:UserModel?
    let manager:Manager?
    let farm:Farm?
    let service:Service?
    let timeslots:TimeSlot?
    let truck:Truck?
}

struct Jobs:Decodable {
    let allJobs:Array<Job>?
    let repeatingJobs:Array<Job>?
}

    
    

struct JobViewModel {
    let service:ServiceViewModel
    let manager:ManagerViewModel
    let customer:CustomerViewModel
    init(job:Job) {
        service = ServiceViewModel(service: job.service)
        manager = ManagerViewModel(manager: job.manager)
        customer = CustomerViewModel(user: job.customer)
    }
}


class JobsViewModel:Pagination {
    
    var isPaginating: Bool = false
    
    var items = Array<JobViewModel>()
    
    func jobs(offSet:Int,success: @escaping (Array<JobViewModel>) -> ()){
        
        let params = [
            "offset": offSet,
            "take": 10
        ]
        
        guard !isPaginating else{
            return
        }
        
        isPaginating = true
        if offSet == 0{
            items.removeAll()
        }
        
        NetworkManager.instance.request(endPoint: .jobs, method: .post, parameters: params, showIndicator: offSet == 0, loadingText: "loading jobs") { [unowned self] (result:NetworkResult<Jobs>) in
            
            
            self.isPaginating = false
            
            switch result{
            case .success(let data):
                let list = data?.allJobs ?? []
                let viewModels = list.map{JobViewModel(job: $0)}
                self.items.append(contentsOf: viewModels)
                success(viewModels)
            case .failure(_):
                break
            }
        }
    }
}
