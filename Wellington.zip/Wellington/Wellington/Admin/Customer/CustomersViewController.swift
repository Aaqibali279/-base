//
//  ServicesViewController.swift
//  Wellington
//
//  Created by Aqib Ali on 12/09/20.
//  Copyright © 2020 Aqib Ali. All rights reserved.
//

import UIKit

class CustomersViewController: UIViewController {
    
    //MARK:- OUTLETS
    @IBOutlet weak var tableView: UITableView!{
        didSet{
            
            let nib = UINib(nibName: "CustomerCell", bundle: .main)
            tableView.register(nib, forCellReuseIdentifier: "CustomerCell")
            
            tableView.delegate = dataSource
            tableView.dataSource = dataSource
            tableView.bounces = false
        }
    }
    
    //MARK:- PROPERTIES
    
    private let customersViewModel = CustomersViewModel()
    
    private lazy var dataSource = TableViewDelegateDatasource<CustomerViewModel>(heightForHeader: 50, cellForRowAt: { [unowned self] (viewModel, indexPath) -> UITableViewCell in
        let cell = self.tableView.dequeueReusableCell(withIdentifier: "CustomerCell", for: indexPath) as! CustomerCell
        cell.customerViewModel = viewModel
        return cell
    },headerForSection: { (section) -> UIView in
        SearchHeaderView(delegate: self)
    },loadMoreData: { [weak self] offset in
        self?.getCustomers(offSet: offset)
    })
    
    //MARK:- FUNCTIONS
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        set(title: "Customers")
        setBackButton()
        getCustomers()
    }
    
    private func getCustomers(offSet:Int = 0){
        tableView.tableFooterView = indicatorFooterView
        customersViewModel.customers(offSet:offSet) { [unowned self] customers in
            self.tableView.tableFooterView = nil
            self.dataSource.items.append(contentsOf: customers)
            self.tableView.reloadData()
        }
    }
}



extension CustomersViewController:SearchHeaderViewDelegate{
    func reloadAll() {
        dataSource.items = customersViewModel.items
        tableView.reloadData()
    }
    
    func search(from text: String) {
        dataSource.items = customersViewModel.items.filter{$0.name.lowercased().contains(text) || $0.email.contains(text)}
        tableView.reloadData()
    }
    
    func add() {
        showSnackBar(message: "Add Tapped")
    }
    
    
}
