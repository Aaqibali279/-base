//
//  CustomersViewModel.swift
//  Wellington
//
//  Created by Aqib Ali on 19/09/20.
//  Copyright © 2020 Aqib Ali. All rights reserved.
//

import Foundation

struct Farm:Decodable {
    let id:Int
    let customer_id:Int
    let farm_address:String?
    let farm_city:String?
    let farm_image:String?
    let farm_province:String?
    let farm_unit:String?
    let farm_zipcode:String?
    let farm_active:Int?
    let latitude:String?
    let longitude:String?
}


struct CustomerViewModel {
    
    var name:String
    let phone:String
    let email:String
    let address:String
    let image:String
    
    let farmList:Array<Farm>?
    
    init(user:UserModel?) {
        if let firstname = user?.first_name,let lastname = user?.last_name{ name = firstname + " " + lastname }else{ name = NOT_AVAILABLE }
        phone = user?.phone ?? NOT_AVAILABLE
        email = user?.email ?? NOT_AVAILABLE
        image = user?.user_image ?? ""
        
        var value = ""
        if let address = user?.address{
            value = address
        }
        if let city = user?.city{
            value += " \(city)"
        }
        if let state = user?.state{
            value += " \(state)"
        }
        if let country = user?.country{
            value += " \(country)"
        }
        if let pincode = user?.zip_code{
            value += " \(pincode)"
        }
        address = value
        self.farmList = user?.farmlist
    }
}


class CustomersViewModel:Pagination {
    
    var isPaginating: Bool = false

    var items = Array<CustomerViewModel>()
    
    func customers(offSet:Int,success: @escaping (Array<CustomerViewModel>) -> ()){
        
        let params = [
            "offset": offSet,
            "take": 10
        ]
        
        guard !isPaginating else{
            return
        }
        
        isPaginating = true
        if offSet == 0{
            items.removeAll()
        }
        
        NetworkManager.instance.request(endPoint: .customers, method: .post, parameters: params, showIndicator: offSet == 0, loadingText: "loading customers") { [unowned self] (result:NetworkResult<Array<UserModel>>) in
            
            self.isPaginating = false
            
            switch result{
            case .success(let data):
                let list = data ?? []
                let viewModels = list.map{CustomerViewModel(user: $0)}
                self.items.append(contentsOf: viewModels)
                success(viewModels)
            case .failure(_):
                break
            }
        }
    }
}
