//
//  CustomerCell.swift
//  Wellington
//
//  Created by Aqib Ali on 20/09/20.
//  Copyright © 2020 Aqib Ali. All rights reserved.
//

import UIKit
import IBAnimatable

class CustomerCell: UITableViewCell {
    

    @IBOutlet weak var iv: AnimatableImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var phoneLabel: UILabel!
    @IBOutlet weak var emailLabel: UILabel!
    @IBOutlet weak var addressLabel: UILabel!
    
    
    var customerViewModel:CustomerViewModel?{
        didSet{
            iv.set(imageFrom: customerViewModel?.image)
            nameLabel.text = customerViewModel?.name
            phoneLabel.text = customerViewModel?.phone
            emailLabel.text = customerViewModel?.email
            addressLabel.text = customerViewModel?.address
        }
    }
    
}
