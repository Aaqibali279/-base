//
//  AdminCell.swift
//  Wellington
//
//  Created by Aqib Ali on 12/09/20.
//  Copyright © 2020 Aqib Ali. All rights reserved.
//

import UIKit
import IBAnimatable

class AdminCell: UITableViewCell {

    //MARK:- OUTLETS
    @IBOutlet weak var iv: AnimatableImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var emailLabel: UILabel!
    @IBOutlet weak var btnEdit: UIButton!
    @IBOutlet weak var btnDelete: UIButton!
    
    var admin:AdminViewModel?{
        didSet{
            nameLabel.text = admin?.name
            emailLabel.text = admin?.email
            iv.set(imageFrom: admin?.image)
        }
    }
    
}
