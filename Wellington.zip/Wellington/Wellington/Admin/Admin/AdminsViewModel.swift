//
//  AdminsViewModel.swift
//  Wellington
//
//  Created by Aqib Ali on 18/09/20.
//  Copyright © 2020 Aqib Ali. All rights reserved.
//

import Foundation

struct Admin:Decodable {
    let id:Int
    let first_name:String?
    let last_name:String?
    let email:String?
    let phone:String?
    let address:String?
    let city:String?
    let state:String?
    let country:String?
    let zip_code:String?
    let user_image:String?
    let role_id:Int?
    let is_confirmed:Int?
    let is_active:Int?
}

struct AdminViewModel {
    
    let image:String?
    let name:String
    let email:String
    
    init(admin:Admin) {
        image = admin.user_image
        if let firstname = admin.first_name,let lastname = admin.last_name{
            name = firstname + " " + lastname
        }else{ name = NOT_AVAILABLE }
        email = admin.email ?? NOT_AVAILABLE
    }
}



protocol Pagination {
    var isPaginating:Bool { get set }
}



class AdminsViewModel:Pagination {
    
    var isPaginating: Bool = false
    
    var allAdmins = Array<AdminViewModel>()
    
    func admins(offSet:Int,success: @escaping (Array<AdminViewModel>) -> ()){
        
        guard !isPaginating else{
            return
        }
        
        isPaginating = true
        if offSet == 0{
            allAdmins.removeAll()
        }
        
        let params = [
            "offset": offSet,
            "take": 10
        ]
        
        NetworkManager.instance.request(endPoint: .admins, method: .post, parameters: params, showIndicator: offSet == 0, loadingText: "loading admins") { [unowned self] (result:NetworkResult<Array<Admin>>) in

            self.isPaginating = false
            
            switch result{
            case .success(let data):
                let array = data ?? []
                let viewModels = array.map{AdminViewModel(admin: $0)}
                self.allAdmins.append(contentsOf: viewModels)
                success(viewModels)
            case .failure(_):
                break
            }
        }
    }
}
