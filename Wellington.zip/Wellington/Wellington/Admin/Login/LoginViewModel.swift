//
//  LoginViewModel.swift
//  Wellington
//
//  Created by Aqib Ali on 14/09/20.
//  Copyright © 2020 Aqib Ali. All rights reserved.
//

import Foundation

struct LoginModel:Decodable {
    let access_token:String
    let user:UserModel
}




struct LoginViewModel {
    
    func login(email:String,password:String,success: @escaping ()->()){
        
        let params = [
            "email": email,
            "password": password
        ]
        MyUserDefaults.instance.set(value: "", key: .token)
        NetworkManager.instance.request(endPoint: .login, method: .post, parameters: params,loadingText: "authenticating") { (result:NetworkResult<LoginModel>) in
            switch result{
            case .success(let data):
                ProfileViewModel.shared.userViewModel = UserViewModel(user: data?.user)
                MyUserDefaults.instance.set(value: data?.access_token, key: .token)
                success()
            case .failure(_):
                break
            }
        }
    }
}
