//
//  LoginViewController.swift
//  Wellington
//
//  Created by Aqib Ali on 12/09/20.
//  Copyright © 2020 Aqib Ali. All rights reserved.
//

import UIKit
import EZSwiftExtensions


struct ResponseData:Decodable {
    
}






class LoginViewController: FormViewController {

    //MARK:- OUTLETS
    @IBOutlet weak var emailTextField:FloatingTextField!
    @IBOutlet weak var passwordTextField:FloatingTextField!
    
    //MARK:- PROPERTIES
    var isLogout = false
    private let loginViewModel = LoginViewModel()
    
    //MARK:- FUNCTIONS
    
    override func viewDidLoad() {
        super.viewDidLoad()
        fields = [emailTextField,passwordTextField]
        
        emailTextField.text = "admin@admin.com"
        passwordTextField.text = "12345678"
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        hideNavBar()
        if isLogout{
            view.transform = .init(translationX: -ez.screenWidth, y: 0)
            UIView.animate(withDuration: 0.3, delay: 0, options: .curveEaseOut, animations: {
                self.view.transform = .identity
            })
        }
    }
    
    
    
    //MARK:- ACTIONS
    
    @IBAction func btnForgotAction(_ sender: Any) {
        if let vc = R.storyboard.main.forgotPasswordViewController(){
            navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    @IBAction func btnSignInAction(_ sender: Any) {
        
        guard let email = emailTextField.text else { return }
        guard let password = passwordTextField.text else { return  }
        
        loginViewModel.login(email: email, password: password){ [weak self] in
            if let vc = R.storyboard.dashboard.dashboardViewController(){
                self?.navigationController?.setViewControllers([vc], animated: true)
            }
        }
        
    }
}
