//
//  UserViewModel.swift
//  Wellington
//
//  Created by Aqib Ali on 20/09/20.
//  Copyright © 2020 Aqib Ali. All rights reserved.
//

import Foundation

struct UserModel:Decodable {
    let id:Int
    let first_name:String?
    let last_name:String?
    let email:String?
    let phone:String?
    let address:String?
    let city:String?
    let state:String?
    let country:String?
    let zip_code:String?
    let user_image:String?
    let role_id:Int?
    let is_confirmed:Int?
    let is_active:Int?
    
    let driver:Driver?
    let farmlist:Array<Farm>?
    
}


struct UserViewModel {
    
    let image:String?
    let name:String
    let email:String
    let phone:String
    
    let user:UserModel?
    
    init(user:UserModel?) {
        image = user?.user_image
        name = (user?.first_name ?? "") + " " + (user?.last_name ?? "")
        phone = user?.phone ?? NOT_AVAILABLE
        email = user?.email ?? NOT_AVAILABLE
        self.user = user
    }
}


class ProfileViewModel {
    
    static let shared = ProfileViewModel()
    private init(){}
    
    var userViewModel:UserViewModel?
    
    func profile(showIndicator:Bool = false,completion:@escaping (Result) -> ()){
        NetworkManager.instance.request(endPoint: .user, method: .get, showIndicator: showIndicator, loadingText: "fetching profile") { (result:NetworkResult<UserModel>) in
            switch result{
            case .success(let user):
                completion(.success)
                self.userViewModel = UserViewModel(user: user)
            default:
                completion(.failure)
                break
            }
        }
    }
    
    
}
