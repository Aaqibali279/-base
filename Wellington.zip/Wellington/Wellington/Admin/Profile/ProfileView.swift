//
//  ProfileView.swift
//  Wellington
//
//  Created by Aqib Ali on 13/09/20.
//  Copyright © 2020 Aqib Ali. All rights reserved.
//

import UIKit
import IBAnimatable

protocol ProfileViewDelegate:class {
    func camera()
    func changePassword()
    func save()
}

class ProfileView: UIView {
    //MARK:- OUTLETS
    @IBOutlet weak var imageView: AnimatableImageView!
    @IBOutlet weak var firstnameTextField: FloatingTextField!
    @IBOutlet weak var lastnameTextField: FloatingTextField!
    @IBOutlet weak var emailTextField: FloatingTextField!
    @IBOutlet weak var passwordTextField: FloatingTextField!
    
    //MARK:- PROPERTIES
    weak var delegate:ProfileViewDelegate?
    var userViewModel:UserViewModel?{
        didSet{
            imageView.set(imageFrom: userViewModel?.image)
            firstnameTextField.text = userViewModel?.user?.first_name
            lastnameTextField.text = userViewModel?.user?.last_name
            emailTextField.text = userViewModel?.email
            passwordTextField.text = "********"
        }
    }
    
    //MARK:- ACTIONS
    @IBAction func btnCameraAction(_ sender: Any) {
        delegate?.camera()
    }
    @IBAction func btnChangePasswordAction(_ sender: Any) {
        delegate?.changePassword()
    }
}
