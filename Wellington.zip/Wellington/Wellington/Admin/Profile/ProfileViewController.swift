//
//  ServicesViewController.swift
//  Wellington
//
//  Created by Aqib Ali on 12/09/20.
//  Copyright © 2020 Aqib Ali. All rights reserved.
//

import UIKit

class ProfileViewController: FormViewController {
    
    //MARK:- PROPERTIES
    private var profileView:ProfileView!
    private lazy var imagePicker = ImagePicker(presentationController: self, delegate: self)
    
    //MARK:- FUNCTIONS
    override func viewDidLoad() {
        super.viewDidLoad()
        profileView = view as? ProfileView
        profileView.delegate = self
        
        fields = [
            profileView.firstnameTextField,
            profileView.lastnameTextField,
            profileView.emailTextField,
            profileView.passwordTextField
        ]
    }
    
    override func viewWillAppear(_ animated: Bool) {
        set(title: "Edit Profile")
        setBackButton()
        setRightBarButton(with: "SAVE", tintColor: R.color.primaryColor(), selector: #selector(save))
        getProfile()
    }
    
    //MARK:- ACTIONS
    
    //MARK:- API's
    private func getProfile(){
        ProfileViewModel.shared.profile(showIndicator: true) { [unowned self] _ in
            self.profileView.userViewModel = ProfileViewModel.shared.userViewModel
        }
    }
    
    @objc func save(){
        
    }
    
}

//MARK:- VIEW DELEGATE

extension ProfileViewController:ProfileViewDelegate{
    
    func camera() {
        imagePicker.present(from: view)
    }
    
    func changePassword() {
        
    }
    
}


extension ProfileViewController:ImagePickerDelegate{
    func didSelect(image: UIImage?) {
        profileView.imageView.image = image
    }
    
    
}





